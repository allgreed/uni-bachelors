#!/bin/bash

# imports
mkdir -p lib
. <(test -e lib/fun.sh || curl -Ls https://raw.githubusercontent.com/ssledz/bash-fun/master/src/fun.sh > lib/fun.sh; cat lib/fun.sh) 
. <(test -e lib/argparse.bash || curl -Ls https://raw.githubusercontent.com/nhoffman/argparse-bash/master/argparse.bash > lib/argparse.bash; cat lib/argparse.bash) 

argparse "$@" <<EOF || exit 1
parser.add_argument("--name", required=True,
                    help="Name prefix")
parser.add_argument("--backup-dir", required=True,
                    help="Backup directory location")
parser.add_argument("--src-path", required=True,
                    help="Directory to backup")
parser.add_argument("--ext", default="",
                    help="Quoted list of file extensions to be backed up, ex: \"jpg png txt\", defaults to all extensions")
parser.add_argument("--gzip", action="store_true",
                    help="Use GZIP compression")
parser.add_argument("--full", action="store_true",
                    help="Perfom full backup")
EOF

PREFIX=$NAME
SUFFIX=$(test $GZIP && ret ".gz" || ret "")
GZIP_FLAG=$(test $GZIP && ret "--gzip" || ret "")
DATE="$(date +%Y_%m_%d_%H_%M_%S)"
TYPE=$(test $FULL && ret 'full' || ret 'incr')
TYPE_FLAG=$(test $FULL && ret '--level=0' || ret '')

FILENAME="$PREFIX"_"$TYPE"_"$DATE".tar$SUFFIX

EXTENSION_REGEXP=$(
    list $(echo $EXT | perl -pe 's/\|/ /g') \
    | map λ ext . 'echo -iname *.$ext' \
    | join ' -o '  '( ' ' )'
)

FIND_ARGS="$SRC_PATH -type f $(
    test "$EXTENSION_REGEXP" = '( )' \
    && echo ''\
    || echo $EXTENSION_REGEXP)"

FILES_TO_BACKUP=$(find $FIND_ARGS)

tar -cvf $BACKUP_DIR/$FILENAME $GZIP_FLAG $TYPE_FLAG -g $BACKUP_DIR/$NAME.snar $FILES_TO_BACKUP
