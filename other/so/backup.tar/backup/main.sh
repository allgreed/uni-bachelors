#!/bin/bash
ARGPARSE_DESCRIPTION="Backup utlity"

# imports
mkdir -p lib
. <(test -e lib/argparse.bash || curl -Ls https://raw.githubusercontent.com/nhoffman/argparse-bash/master/argparse.bash > lib/argparse.bash; cat lib/argparse.bash) 

argparse "$@" <<EOF || exit 1
parser.add_argument("-v", "--version", action="store_true",
    help="Print version and exit")
parser.add_argument("subcommand",
    help="Valid values are [ backup | restore | plan ]")
parser.add_argument("_", nargs=argparse.REMAINDER)
EOF

if [[ ! -z "$VERSION" ]]; then
    echo "Latest, always latest"
    exit 0
fi

shift # get rid of the subcommand when forwarding args

case $SUBCOMMAND in
    backup)
        TRANSFORMED_EXT_ARG=$(echo $@ \
            | grep -oP '\-\-ext(\s\w+)+' \
            | perl -pe 's/\s/|/g and s/--ext|/--ext / and s/\|(.*)\|/$1/')

        BACKUP_ARGS=$(echo $@ \
            | perl -pe "s/--ext(\s\w+)+/$TRANSFORMED_EXT_ARG/")
        ./backup.sh $BACKUP_ARGS
        ;;
    restore)
        ./restore.sh $@
        ;;
    plan)
        ./plan.sh $@
        ;;
    *)
        echo 'Err: unknown subcommand. Use -h switch for help' 1>&2
        exit 1
esac
