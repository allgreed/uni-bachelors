BACKUP_COMMAND='./main.sh backup --name backup --backup-dir dest --src-path src'
 
rm -r src/*
rm -r dest/*
rm -r target/*

mkdir -p src/siemano

echo "mammamiamammamiammammia" > src/siemano/1.txt
eval $BACKUP_COMMAND
sleep 1

echo "RESTORING!"
./main.sh restore --name backup --date $(date +%Y_%m_%d_%H_%M_%S) --backup-dir dest --out-dir target

echo "bleble" > src/2.png
eval "$BACKUP_COMMAND --full --ext jpg txt"
sleep 1

echo "supertest" >> src/3.jpg
eval "$BACKUP_COMMAND --gzip"
sleep 1

echo "co jest doktorku?" >> src/3.jpg
eval "$BACKUP_COMMAND --ext jpg txt"
sleep 1

echo "no elo" >> src/4.txt
eval "$BACKUP_COMMAND --full"
sleep 1

echo "łaba dab dab dab" >> src/5.txt
echo "incr 4" >> src/4.txt
eval "$BACKUP_COMMAND --ext jpg txt"

touch dest/whatever.tar
touch dest/whatever.tar.gz
touch dest/backup_incr_444_555_666_777_88_99.tar.gz.niepasuje
touch dest/niepasujebackup_incr_444_555_666_777_88_99.tar.gz

echo "RESTORING!"
./main.sh restore --name backup --date $(date +%Y_%m_%d_%H_%M_%S) --backup-dir dest --out-dir target
