#!/bin/bash

# imports
mkdir -p lib
. <(test -e lib/fun.sh || curl -Ls https://raw.githubusercontent.com/ssledz/bash-fun/master/src/fun.sh > lib/fun.sh; cat lib/fun.sh) 
. <(test -e lib/argparse.bash || curl -Ls https://raw.githubusercontent.com/nhoffman/argparse-bash/master/argparse.bash > lib/argparse.bash; cat lib/argparse.bash) 

argparse "$@" <<EOF || exit 1
parser.add_argument("--name", required=True,
                    help="Name prefix")
parser.add_argument("--date", required=True,
                    help="Restoration date [inclusive]")
parser.add_argument("--backup-dir", required=True,
                    help="Backup directory location")
parser.add_argument("--out-dir", required=True,
                    help="Output directory location")
EOF

function restore_backup
{
    tar --listed-incremental=/dev/null -xvf $BACKUP_DIR/$1 -C $OUT_DIR
}

function get_date_from_filename
{
    echo $1 \
    | grep -oP '_(full|incr)_\K[\d_]*'
    # String is fine here, as the format I am using has the same format lexicographically and when casted to integer
}

function get_last_full_backup
{
    list $1 \
    | grep -P '^'"$NAME"'_full_\K[\d_]*\.tar(\.gz)?$' \
    | sort \
    | tail -n 1
}

LAST_BACKUP_DATE=$(get_date_from_filename $(get_last_full_backup "$(list $(ls dest))"))
# Everything is >= empty string -> therefore everything will work even when there is no last full backup

list $(ls $BACKUP_DIR) \
    | grep -P '^'"$NAME"'_(full|incr)_\K[\d_]*\.tar(\.gz)?$' \
    | filter λ filename . '[[ ! $(get_date_from_filename $filename) < $LAST_BACKUP_DATE ]] && ret true || ret false' \
    | filter λ filename . '[[ ! $(get_date_from_filename $filename) > $DATE ]] && ret true || ret false' \
    | sort \
    | map λ filename . 'restore_backup $filename'
